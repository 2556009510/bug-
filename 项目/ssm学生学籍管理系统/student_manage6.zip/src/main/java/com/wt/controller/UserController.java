package com.wt.controller;

import com.wt.entity.User;
import com.wt.entity.User;
import com.wt.service.UserService;
import com.wt.service.UserService;
import com.wt.utils.MD5Utils;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    private static final String LIST = "user/list"; //表页面
    private static final String ADD = "user/add";   //添加页面
    private static final String UPDATE = "user/update";//更新页面

    @Autowired
    private UserService userService;

    @GetMapping("/add")
    public String add(){
        return ADD;
    }
    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String,Object> create(@RequestBody User user){
        int result = userService.create(user);
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }
    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String,Object> delete(@PathVariable("id") Integer id){
        int result = userService.delete(id);
        if(result<=0){
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }
    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String,Object> delete(String ids){
        int result = userService.delete(ids);
        if(result<=0){
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }
    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String,Object> update(@RequestBody User user){
        int result = userService.update(user);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }
    //详情（解决删除操作）
    @GetMapping("/detail/{id}")
    //@ResponseBody
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap){
        User user = userService.detail(id);
        //  if(user == null){
        //     return MapControll.getInstance().nodata().getMap();
        //  }
        //  return MapControll.getInstance().success().put("data",user).getMap();
        modelMap.addAttribute("user",user);
        return UPDATE;
    }
    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody User user) {
        List<User> list = userService.query(user);
        Integer count = userService.count(user);
        return MapControll.getInstance().success()
                .put("data",list)
                .put("count",count)
                .getMap(); //put("data",user)是整个对象
    }
    @GetMapping("/list")
    public String list(){
        return LIST;
    }
}



