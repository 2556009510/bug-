package com.wt.controller;

import com.wt.entity.*;
import com.wt.service.*;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.*;


import com.wt.entity.Score;
import com.wt.entity.Subject;
import com.wt.service.ScoreService;
import com.wt.service.SubjectService;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/score")
public class ScoreController {
    private static final String LIST = "score/list"; //表页面
    private static final String ADD = "score/add";   //添加页面
    private static final String UPDATE = "score/update";//更新页面

    @Autowired
    private ScoreService scoreService;
    //====================================== 成绩查询（学生登入）================================================
    @Autowired
    private SubjectService subjectService;//学科
    @Autowired
    private CourseService courseService;  //课程
    @Autowired
    private SectionService sectionService;//部门
    //============================================================================================


/*  @GetMapping("/add")
    public String add(ModelMap modelMap) {
        //======================================= 添加 ===============================================
        List<Subject> subjects = subjectService.query(null);
        modelMap.addAttribute("subjects", subjects); //增加属性
        //============================================================================================
        return ADD;
    }
*/

    //======================================== 学生选课 ======================================================
    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String, Object> create(String sectionIds, String courseIds, HttpSession session) {
        Student student = (Student) session.getAttribute("user");
        int result = scoreService.create(sectionIds, courseIds, student.getId());
//============================================================================================
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String, Object> delete(@PathVariable("id") Integer id) {
        int result = scoreService.delete(id);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

/*
    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String ids) {
        int result = scoreService.delete(ids);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }
*/

    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Score score) {
        int result = scoreService.update(score);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    //======================================= 修改 ===============================================
    //详情（解决删除操作）
    //@GetMapping("/detail/{id}")
    @PostMapping("/detail/{id}")
    @ResponseBody
//    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
    public Map<String, Object> detail(@PathVariable("id") Integer id) {
        Score score = scoreService.detail(id);
        //List<Subject> subjects = subjectService.query(null);
        if (score == null) {
            return MapControll.getInstance().nodata().getMap();
        }
        return MapControll.getInstance().success()
                .put("data", score)
                .getMap();
        //modelMap.addAttribute("score", score);
        //modelMap.addAttribute("subjects", subjects); //增加属性
        //return UPDATE;
    }
    //============================================================================================

    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody Score score) {
        List<Score> list = scoreService.query(score);
		/*
        List<Subject> subjects = subjectService.query(null);
        //循环赋值
        //设置subject
        list.forEach(entity -> {
            subjects.forEach(subject -> {
                if (entity.getSubjectId() == subject.getId()) {
                    entity.setSubject(subject);
                }
            });
        });
        Integer count = scoreService.count(score);
		*/
        return MapControll.getInstance().success()
                .put("data", list)
                //.put("count", count)
                .getMap(); //put("data",score)是整个对象
    }

//    @GetMapping("/list")
//    public String list() {
//        return LIST;
//    }

    //====================================== 成绩查询（学生登入）================================================
    @GetMapping("/student_score")  //成绩查询
    public String student_score() {
        return "score/student_score";
    }
    //==========================================================================================================

    @PostMapping("/student_score")
    @ResponseBody
    public Map<String, Object> student_score(Score score, HttpSession session) {
        Student student = (Student) session.getAttribute("user");
        List<HashMap> mapList = scoreService.queryScoreByStudent(student.getId());
        return MapControll.getInstance().success()
                .put("data", mapList)
                .getMap();
    }

//    @PostMapping("/student_score")
//    @ResponseBody
//    public Map<String, Object> student_score(Score score, HttpSession session) {
//        Student student = (Student) session.getAttribute("user");
//        Score score = new Score();
//        score.setStuId(student.getId);
//        //按照学生ID查询班级设置课程信息
//        List<Score> scores = scoreService.query(score);
//        List<Course> courses = courseService.query(null);
//        List<Section> sections = sectionService.query(null);
//        //设置关联对象
//        scores.forEach(entity -> {
//            courses.forEach(course -> {
//                if (entity.getCourseId() == course.getId().intValue()) {
//                    entity.setCourse(course);
//                }
//            });
//            sections.forEach(section -> {
//                if (entity.getSectionId() == section.getId().intValue()) {
//                    entity.setSection(section);
//                }
//            });
//            entity.setStudent(student);
//        });
//        return MapControll.getInstance().success()
//                .put("data", scors)
//                .getMap();
//    }

}


