package com.wt.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapControll {
//========================================== 添加 ===========================================
    //枚举类型
    private static final String SUCCESS = "1000";
    private static final String ERROR = "1001";
    private static final String NODATA = "1002";
//============================================================================================

    //目标对象
    private Map<String, Object> paramMap = new HashMap<>();

    //私有构造
    private MapControll() {
    }

    //我要告诉你我返回对象
    public static MapControll getInstance() {
        return new MapControll();
    }

    public MapControll add(String key, Object value) {
        paramMap.put(key, value);
        return this;
    }

//========================================== 添加 ===========================================
    //成功
    public MapControll success() {
//        paramMap.put(SUCCESS, "操作成功"); //之前只写这一行也能测试
        paramMap.put("code", SUCCESS);
        paramMap.put("msg", "操作成功");
        return this;
    }

    //失败
    public MapControll error() {
//        paramMap.put(ERROR, "操作失败"); //之前只写这一行也能测试
        paramMap.put("code", ERROR);
        paramMap.put("msg", "操作失败");
        return this;
    }
    //复制上面方法，只添加有参
    //验证码、用户和密码错误
    public MapControll error(String msg) {
        paramMap.put("code", ERROR);
        paramMap.put("msg", msg);
        return this;
    }

    //空值
    public MapControll nodata() {
//        paramMap.put(NODATA, "暂无数据"); //之前只写这一行也能测试
        paramMap.put("code", NODATA);
        paramMap.put("1001", "暂无数据");
        return this;
    }

    public MapControll put(String key, Object value) {
        this.add(key, value);
        return this;
    }
//    public MapControll page(List<?> list, Integer count){
//        paramMap.put("data",list);
//        paramMap.put("count",count);
//        return this;
//    }

//============================================================================================
    public MapControll addId(Object value) {
        paramMap.put("id", value);
        return this;
    }

    public MapControll add(Map<String, Object> map) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            paramMap.put(entry.getKey(), entry.getValue());
        }
        return this;
    }

//========================================== 添加 ============================================
    public MapControll put(Map<String, Object> map) {
        return this.add(map);
    }

//============================================================================================
    //ClazzService.java中少一个对象报错
    public Map<String, Object> getMap() {
        return paramMap;
    }
}
