package com.wt.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wt.entity.*;
import com.wt.service.*;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/section")
public class SectionController {

    private static final String LIST = "section/list"; //表页面
    private static final String ADD = "section/add";   //添加页面
    private static final String UPDATE = "section/update";//更新页面

    @Autowired
    private SectionService sectionService; //部门
    @Autowired
    private SubjectService subjectService; //学科
    @Autowired
    private ClazzService clazzService;     //班级
    @Autowired
    private TeacherService teacherService; //老师
    @Autowired
    private CourseService courseService;   //课程
    @Autowired
    private StudentService studentService; //学生
    @Autowired
    private ScoreService scoreService;     //得分


    @GetMapping("/add")
//======================================= 添加 ===============================================
    public String add(Integer clazzId, ModelMap modelMap) {  //添加(Integer clazzId)
        List<Teacher> teachers = teacherService.query(null);
        List<Course> courses = courseService.query(null);
        modelMap.put("teachers", teachers);//增加属性
        modelMap.put("courses", courses);  //增加属性
        modelMap.put("clazzId", clazzId);  //增加属性
//============================================================================================
        return ADD;
    }

    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Section section) {
        int result = sectionService.create(section);
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String, Object> delete(@PathVariable("id") Integer id) {
        int result = sectionService.delete(id);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String ids) {
        int result = sectionService.delete(ids);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Section section) {
        int result = sectionService.update(section);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    //======================================= 修改 ===============================================
    //详情（解决删除操作）
    @GetMapping("/detail/{id}")
    //@ResponseBody
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        Section section = sectionService.detail(id);
//======================================== 添加 ==============================================
        List<Teacher> teachers = teacherService.query(null);
        List<Course> courses = courseService.query(null);
        modelMap.put("teachers", teachers);
        modelMap.put("courses", courses);
//============================================================================================
        modelMap.addAttribute("section", section);
        return UPDATE;

    }

    //============================================================================================
    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody Section section) {

        List<Section> list = sectionService.query(section);
        //============================== 老师、课程 ===============================================
        List<Teacher> teachers = teacherService.query(null);
        List<Course> courses = courseService.query(null);
        //modelMap.addAttribute("teachers",teachers);//增加属性
        //modelMap.addAttribute("courses", courses); //增加属性

        list.forEach(entity -> {
            teachers.forEach(teacher -> {
                if (teacher.getId() == entity.getTeacherId()) {
                    entity.setTeacher(teacher);
                }
            });
            courses.forEach(course -> {
                if (course.getId() == entity.getCourseId()) {
                    entity.setCourse(course);
                }
            });
        });
        //============================================================================================
        Integer count = sectionService.count(section);
        return MapControll.getInstance().success()
                .put("data", list)
                .put("count", count)
                .getMap(); //put("data",section)是整个对象
    }

    @GetMapping("/list")
    public String list() {
        return LIST;
    }

    //    ================================ 复制上面的query()方法 ====================================
    @PostMapping("/tree")
    @ResponseBody
    public List<Map> tree() {
        List<Subject> subjects = subjectService.query(null);
        List<Clazz> clazzes = clazzService.query(null);
        List<Map> list = new ArrayList<>();
//====================================== 看下面图片 ==========================================
        subjects.forEach(subject -> {
            Map<String, Object> map = new HashMap<>(); //一个专业所对应的（父亲节点）
            map.put("id", subject.getId());
            map.put("name", subject.getSubjectName());
            map.put("parentId", 0);

            List<Map<String, Object>> childrenList = new ArrayList<>(); //孩子节点
            clazzes.forEach(clazz -> {
                if (subject.getId() == clazz.getSubjectId()) {
                    Map<String, Object> children = new HashMap<>(); //孩子节点
                    children.put("id", clazz.getId());
                    children.put("name", clazz.getClazzName());
                    children.put("parentId", subject.getId());
                    childrenList.add(children);
                }
            });
            map.put("children", childrenList);
            list.add(map);
        });
//============================================================================================
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String jsonString = objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return list;
    }
//============================================================================================

    //学生登入
    @GetMapping("/student_section")
    public String student_section() {
        return "section/student_section";
    }

    @PostMapping("/query_student_section")
    @ResponseBody
    public Map<String, Object> query_student_select(HttpSession session) { //查询学生部门
        //获取Student
        Student param = (Student) session.getAttribute("user");
        //按照学生ID查询班级设置课程信息
        List<Section> sections = sectionService.queryByStudent(param.getId());
        List<Clazz> clazzes = clazzService.query(null);
        List<Teacher> teachers = teacherService.query(null);
        List<Course> courses = courseService.query(null);
        //设置关联对象
        sections.forEach(section -> {
            clazzes.forEach(clazz -> {
                if (section.getClazzId() == clazz.getId().intValue()) {
                    section.setClazz(clazz);
                }
            });
            teachers.forEach(teacher -> {
                if (section.getTeacherId() == teacher.getId().intValue()) {
                    section.setTeacher(teacher);
                }
            });
            courses.forEach(course -> {
                if (section.getCourseId() == course.getId().intValue()) {
                    section.setCourse(course);
                }
            });
        });
        return MapControll.getInstance().success()
                .add("data", sections)
                .getMap();
    }

    //老师登入
    @GetMapping("/teacher_section")
    public String teacher_section() {
        return "section/teacher_section";
    }

    @PostMapping("/query_teacher_section")
    @ResponseBody
    public Map<String, Object> query_teacher_section(HttpSession session) {
        //获取Teacher
        Teacher param = (Teacher) session.getAttribute("user");
        //按照学生ID查询班级设置课程信息
        List<Section> sections = sectionService.queryByTeacher(param.getId());
        List<Course> courses = courseService.query(null);
        List<Clazz> clazzes = clazzService.query(null);
        //设置关联对象
        sections.forEach(section -> {
            courses.forEach(course -> {
                if (section.getCourseId() == course.getId().intValue()) {
                    section.setCourse(course);
                }
            });
            clazzes.forEach(clazz -> {
                if (section.getClazzId() == clazz.getId().intValue()) {
                    section.setClazz(clazz);
                }
            });
        });
        return MapControll.getInstance().success()
                .add("data", sections)
                .getMap();
    }

    //老师评分
    @GetMapping("/teacher_student_score")
    public String teacher_student_score(Integer courseId, Integer sectionId, ModelMap modelMap) {
        List<HashMap> list = studentService.querySelectStudent(courseId, sectionId);
        modelMap.put("list", list);
        modelMap.put("sectionId", sectionId);
        modelMap.put("courseId", courseId);
        return "section/teacher_student_score";
    }

    @PostMapping("/teacher_student_score")
    @ResponseBody
    public Map<String, Object> teacher_student_score(Integer courseId, Integer sectionId, String stuIds, String scores) {
        int flag = scoreService.update(courseId, sectionId, stuIds, scores);
        if (flag <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }


}



