package com.wt.utils;

import java.io.Serializable;

public class Entity implements Serializable {

    private Integer page;  //页
    private Integer limit; //列

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }
}
