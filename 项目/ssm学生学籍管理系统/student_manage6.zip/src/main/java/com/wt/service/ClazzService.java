package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.ClazzDao;
import com.wt.dao.UserDao;
import com.wt.entity.Clazz;
import com.wt.entity.User;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ClazzService {
    @Autowired
    private ClazzDao clazzDao;

    public int create(Clazz pi){
        return clazzDao.create(pi);
    }
    public int delete(Integer id) {
        return clazzDao.delete(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }
//======================================= 添加 ===============================================
    public int delete(String ids) {
        int flag = 0;
        for (String str : ids.split(",")) {
            flag = clazzDao.delete(MapParameter.getInstance()
                    .addId(Integer.parseInt(str))
                    .getMap());
        }
        return flag;
    }
//============================================================================================
    public int update(Clazz clazz){
        Map<String, Object> map = MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(clazz))
                .addId(clazz.getId())
                .getMap();
        return clazzDao.update(map);
    }
    public List<Clazz> query(Clazz clazz){
        if(clazz!= null && clazz.getPage() != null){
            PageHelper.startPage(clazz.getPage(),clazz.getLimit());
        }
        return clazzDao.query(BeanMapUtils.beanToMap(clazz));
    }
    public Clazz detail(Integer id){
        return clazzDao.detail(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }
    public int count(Clazz clazz){
        return clazzDao.count(BeanMapUtils.beanToMap(clazz));
    }
}

