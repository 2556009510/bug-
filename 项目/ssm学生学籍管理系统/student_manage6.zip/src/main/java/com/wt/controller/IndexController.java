package com.wt.controller;

import com.wt.entity.*;
import com.wt.service.*;
import com.wt.utils.MD5Utils;
import com.wt.utils.MapControll;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class IndexController {

    //=================================== 修改密码 =======================================================
    @Autowired
    UserService userService;
    @Autowired
    TeacherService teacherService;
    @Autowired
    StudentService studentService;
    @Autowired
    ClazzService clazzService;
    @Autowired
    SubjectService subjectService;
    @Autowired
    CourseService courseService;
    @Autowired
    SectionService sectionService;
    @Autowired
    ScoreService scoreService;
    //============================================================================================


    @GetMapping("/index")
    public String index() {
        return "index";
    }

    //查看个人信息
    @GetMapping("/info")
    public String info() {
        return "info";
    }

    //=================================== 修改密码 =======================================================
    @GetMapping("/pwd")
    public String pwd() {
        return "pwd";
    }

    @PostMapping("/pwd")
    @ResponseBody
    public Map<String, Object> pwd(Integer id, String type, String sourcePwd, String newPwd) {
        //管理员
        if ("1".equals(type)) {
            User user = userService.detail(id);
            if (user.getUserPwd().equals(MD5Utils.getMD5(sourcePwd))) {
                User entity = new User();
                entity.setId(id);
                entity.setUserPwd(MD5Utils.getMD5(newPwd));
                int update = userService.update(entity);
                if (update > 0) {
                    return MapControll.getInstance().success().getMap();
                } else {
                    return MapControll.getInstance().error().getMap();
                }
            } else {
                return MapControll.getInstance().error("原密码错误").getMap();
            }
        }
        //老师
        if ("2".equals(type)) {
            Teacher teacher = teacherService.detail(id);
            if (teacher.getTeacherPwd().equals(MD5Utils.getMD5(sourcePwd))) {
                Teacher entity = new Teacher();
                entity.setId(id);
                entity.setTeacherPwd(MD5Utils.getMD5(newPwd));
                int update = teacherService.update(entity);
                if (update > 0) {
                    return MapControll.getInstance().success().getMap();
                } else {
                    return MapControll.getInstance().error().getMap();
                }
            } else {
                return MapControll.getInstance().error("原密码错误").getMap();
            }
        }
        //学生
        if ("3".equals(type)) {
            Student student = studentService.detail(id);
            if (student.getStuPwd().equals(MD5Utils.getMD5(sourcePwd))) {
                Student entity = new Student();
                entity.setId(id);
                entity.setStuPwd(MD5Utils.getMD5(newPwd));
                int update = studentService.update(entity);
                if (update > 0) {
                    return MapControll.getInstance().success().getMap();
                } else {
                    return MapControll.getInstance().error().getMap();
                }
            } else {
                return MapControll.getInstance().error("原密码错误").getMap();
            }
        }
        return MapControll.getInstance().error().getMap();
    }

    //===================================== 图表 ===============================================
    @GetMapping("/main")
    public String main(ModelMap modelMap) {
        //2、每个班级的学生数量
        List<Map<String, Object>> clazzList = new ArrayList<>();
        List<Clazz> clazzes = clazzService.query(null);
        List<Student> students = studentService.query(null);
        for (Clazz clazz : clazzes) {
            Map<String, Object> map = new HashMap<>();
            map.put("name", clazz.getClazzName());
            int cnt = 0;
            for (Student student : students) {
                if (clazz.getId().intValue() == student.getClazzId()) {
                    cnt++;
                }
            }
            map.put("cnt", cnt);
            clazzList.add(map);
        }
        modelMap.put("clazzList", clazzList);
        //3、查询各科平均成绩
        List<HashMap> scoreList = scoreService.queryAvgScoreBySection();
        modelMap.put("scoreList", scoreList);
        return "main";
    }

    //1、系统数据概览
    @PostMapping("/sum")
    @ResponseBody
    public Map<String, Object> sum() {
        List<Clazz> clazzes = clazzService.query(null);
        List<Subject> subjects = subjectService.query(null);
        List<Teacher> teachers = teacherService.query(null);
        List<Course> courses = courseService.query(null);
        List<Section> sections = sectionService.query(null);
        List<Student> students = studentService.query(null);
        Map<String, Object> map = MapParameter.getInstance()
                .add("clazzCnt", clazzes.size())
                .add("subjectCnt", subjects.size())
                .add("teacherCnt", teachers.size())
                .add("courseCnt", courses.size())
                .add("studentCnt", students.size())
                .add("sectionCnt", sections.size())
                .getMap();
        return MapControll.getInstance().success().add("data", map).getMap();
    }
    //============================================================================================


}

