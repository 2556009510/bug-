package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.StudentDao;
import com.wt.dao.StudentDao;
import com.wt.entity.Student;
import com.wt.entity.Student;
import com.wt.entity.Teacher;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MD5Utils;
//import com.wt.utils.MapParameter;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MD5Utils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class StudentService {

    @Autowired
    private StudentDao studentDao;

    public int create(Student pi) {
        //===================================== 学生登录 =============================================
        pi.setStuPwd(MD5Utils.getMD5(pi.getStuPwd()));
        //============================================================================================
        return studentDao.create(pi);
    }

    public int delete(Integer id) {
        return studentDao.delete(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }

    //===================================== 添加 ==============================================
    public int delete(String ids) {
        int flag = 0;
        for (String s : ids.split(",")) {
            flag = studentDao.delete(MapParameter.getInstance()
                    .addId(Integer.parseInt(s))
                    .getMap());
        }
        return flag;
    }

    //============================================================================================
    public int update(Student student) {
        Map<String, Object> map = MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(student))
                .addId(student.getId())
                .getMap();
        return studentDao.update(map);
    }

    public List<Student> query(Student student) {
        //这些类的query()方法中，都粘贴这个
//        if (student != null && student.getPage() != null) {
//            PageHelper.startPage(student.getPage(), student.getLimit());
//        }
        return studentDao.query(BeanMapUtils.beanToMap(student));
    }

    public Student detail(Integer id) {
        return studentDao.detail(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }

    public int count(Student student) {
        return studentDao.count(BeanMapUtils.beanToMap(student));
    }

    //===================================== 学生登录 ==============================================
    public Student login(String userName, String password) {
        Map<String, Object> map = MapParameter.getInstance()
                .add("stuNo", userName) //学号
                .add("stuPwd", password)
                .getMap();
        return studentDao.detail(map);
    }
//============================================================================================

    //老师查询学生信息
    public List<Student> queryStudentByTeacher(Integer teacherId,Integer clazzId,Integer subjectId){
        Map<String, Object> map = MapParameter.getInstance()
                .add("teacherId", teacherId) //老师ID
                .add("clazzId", clazzId)     //班级ID
                .add("subjectId", subjectId) //学科ID
                .getMap();
        return studentDao.queryStudentByTeacher(map);
    }

    //查询选课的学生信息
    public List<HashMap> querySelectStudent(Integer courseId, Integer sectionId){
        Map<String, Object> map = MapParameter.getInstance()
                .add("courseId", courseId)   //课程ID
                .add("sectionId", sectionId) //部门ID
                .getMap();
        return studentDao.querySelectStudent(map);
    }









}


