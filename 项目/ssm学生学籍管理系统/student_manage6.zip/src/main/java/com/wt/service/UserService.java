package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.UserDao;
import com.wt.entity.User;
import com.wt.entity.User;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    public int create(User pi) {
        return userDao.create(pi);
    }

    public int delete(Integer id) {
        return userDao.delete(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }
    //============================================================================
    //复制上面的方法，并修改部分代码
    public int delete(String ids) {
        int flag = 0;
        for (String str : ids.split(",")) {
            flag = userDao.delete(MapParameter.getInstance()
                    .addId(Integer.parseInt(str))
                    .getMap());
        }
        return flag;
    }
    //============================================================================
    public int update(User user) {
        Map<String, Object> map = MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(user))
                .addId(user.getId())
                .getMap();
        return userDao.update(map);
    }

    public List<User> query(User user) {
        //当查询条件有分页信息时，按照分页查询
        if(user != null && user.getPage() != null){
            PageHelper.startPage(user.getPage(),user.getLimit());
        }
        return userDao.query(BeanMapUtils.beanToMap(user));
    }

    public User detail(Integer id) {
        //{}内容与上面的delete()方法一样
        return userDao.detail(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }

    public int count(User user) {
        return userDao.count(BeanMapUtils.beanToMap(user));
    }
//===================================== 管理员登录 =============================================
    public User login(String userName,String password){
        Map<String, Object> map = MapParameter.getInstance()
                .add("userName", userName)
                .add("userPwd", password)
                .getMap();
        return userDao.detail(map);
    }
//============================================================================================
}
