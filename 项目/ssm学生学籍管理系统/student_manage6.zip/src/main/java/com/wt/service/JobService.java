package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.JobDao;
import com.wt.entity.Job;
import com.wt.entity.Job;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MapParameter;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class JobService {

    @Autowired
    private JobDao jobDao;

    public int create(Job pi) {
        return jobDao.create(pi);
    }

    public int delete(Integer id) {
        return jobDao.delete(MapParameter.getInstance().addId(id).getMap());
    }

    public int update(Job job) {
        return jobDao.update(BeanMapUtils.beanToMapForUpdate(job));
    }

    public List<Job> query(Job job) {
        if (job != null && job.getPage() != null) {
            PageHelper.startPage(job.getPage(), job.getLimit());
        }
        return jobDao.query(BeanMapUtils.beanToMap(job));
    }

    public Job detail(Integer id) {
        //{}内容与上面的delete()方法一样
        return jobDao.detail(MapParameter.getInstance().addId(id).getMap());
    }

    public int count(Job job) {
        return jobDao.count(BeanMapUtils.beanToMapForUpdate(job));
    }

}
