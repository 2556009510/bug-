package com.wt;

public class Person {

    public Person(){
        System.out.println("Person././.....");
    }

}
