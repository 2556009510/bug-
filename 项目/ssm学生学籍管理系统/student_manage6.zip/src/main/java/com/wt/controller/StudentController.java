package com.wt.controller;

import com.wt.entity.Clazz;
import com.wt.entity.Student;
import com.wt.entity.Subject;
import com.wt.entity.Teacher;
import com.wt.service.ClazzService;
import com.wt.service.StudentService;
import com.wt.service.SubjectService;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/student")
public class StudentController {

    private static final String LIST = "student/list"; //表页面
    private static final String ADD = "student/add";   //添加页面
    private static final String UPDATE = "student/update";//更新页面

    @Autowired
    private StudentService studentService;
    @Autowired
    private SubjectService subjectService;
    @Autowired
    private ClazzService clazzService;


    @GetMapping("/add")
    public String add(ModelMap modelMap) {
        List<Subject> subjects = subjectService.query(null);
        modelMap.addAttribute("subjects", subjects); //增加属性
        return ADD;
    }

    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Student student) {
        int result = studentService.create(student);
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String, Object> delete(@PathVariable("id") Integer id) {
        int result = studentService.delete(id);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String ids) {
        int result = studentService.delete(ids);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Student student) {
        int result = studentService.update(student);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    //详情（解决删除操作）
    @GetMapping("/detail/{id}")
    //@ResponseBody
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        Student student = studentService.detail(id);
        List<Subject> subjects = subjectService.query(null);
        //if(student == null){
        //return MapControll.getInstance().nodata().getMap();
        //}
        //return MapControll.getInstance().success().put("data",student).getMap();
        modelMap.addAttribute("student", student);
        modelMap.addAttribute("subjects", subjects); //增加属性
        return UPDATE;
    }

    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody Student student) {
        List<Student> list = studentService.query(student);
        List<Subject> subjects = subjectService.query(null);
//======================================= 添加 ===============================================
        List<Clazz> clazzes = clazzService.query(null);
        //设置关联关系
        list.forEach(entity -> {
            subjects.forEach(subject -> {
                if(subject.getId() == entity.getSubjectId()){
                    entity.setSubject(subject);
                }
            });
            clazzes.forEach(clazz -> {
                if(clazz.getId() == entity.getClazzId()){
                    entity.setClazz(clazz);
                }
            });
        });
//============================================================================================
        Integer count = studentService.count(student);
        return MapControll.getInstance().success()
                .put("data", list)
                .put("count", count)
                .getMap(); //put("data",student)是整个对象
    }

    @GetMapping("/list")
    public String list() {
        return LIST;
    }

    //================================== 学生查询 ============================================
    @GetMapping("/teacher_student")
    public String teacher_student(HttpSession session,ModelMap modelMap){
        Teacher teacher = (Teacher) session.getAttribute("user");
        List<Clazz> clazzes = clazzService.query(null);
        List<Subject> subjects = subjectService.query(null);
        modelMap.addAttribute("clazzes",clazzes);
        modelMap.addAttribute("subjects",subjects);
        modelMap.addAttribute("teacherId",teacher.getId());
        return "student/teacher_student";
    }
    @PostMapping("/teacher_student")
    @ResponseBody
    public Map<String,Object> teacher_student(Integer teacherId,Integer clazzId,Integer subjectId){
        List<Student> students = studentService.queryStudentByTeacher(teacherId, clazzId, subjectId);
        List<Subject> subjects = subjectService.query(null);
        List<Clazz> clazzes = clazzService.query(null);
        //设置关联关系
        students.forEach(entity->{
            subjects.forEach(subject -> {
                if(subject.getId() == entity.getSubjectId()){
                    entity.setSubject(subject);
                }
            });
            clazzes.forEach(clazz -> {
                if(clazz.getId() == entity.getClazzId()){
                    entity.setClazz(clazz);
                }
            });
        });
        return MapControll.getInstance().success().add("data",students).getMap();
    }
    //=====================================================================================

    //================================= 查看个人信息 =============================================
    @GetMapping("/info")
    public String info(HttpSession session, ModelMap modelMap){
        //获取Student
        Student param = (Student) session.getAttribute("user");
        Student student = studentService.detail(param.getId());
        modelMap.put("student",student);
        return "student/info";
    }
    //=====================================================================================




}


