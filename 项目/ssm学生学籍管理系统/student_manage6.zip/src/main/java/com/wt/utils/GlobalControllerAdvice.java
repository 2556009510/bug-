package com.wt.utils;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@ControllerAdvice
public class GlobalControllerAdvice {

    private final String ERROR = "error"; //如果访问限制就转到error.jsp文件页面（显示404）

    @ExceptionHandler(value = PermissionException.class)
    //没有权限
    public ModelAndView noPermission(PermissionException e) {
        ModelAndView modelAndView = new ModelAndView(ERROR);
        modelAndView.addObject(ERROR, e.getMessage());
        return modelAndView;
    }

    @ExceptionHandler(value = RuntimeException.class)
    @ResponseBody
    //运行时异常
    public Map<String, Object> runtimeException(RuntimeException e) {
        //========================================= 添加 =============================================
        e.printStackTrace();  //错误信息显示在控制台
        //============================================================================================
        return MapControll.getInstance().error(e.getMessage()).getMap();
    }
}


