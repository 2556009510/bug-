package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.CourseDao;
import com.wt.dao.CourseDao;
import com.wt.entity.Course;
import com.wt.entity.Course;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MapParameter;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CourseService {

    @Autowired
    private CourseDao courseDao;

    public int create(Course pi) {
        return courseDao.create(pi);
    }

    public int delete(Integer id) {
        return courseDao.delete(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }
    //======================================= 添加 ===============================================
    public int delete(String ids) {
        int flag = 0;
        for (String s : ids.split(",")) {
            flag = courseDao.delete(MapParameter.getInstance()
                    .addId(Integer.parseInt(s))
                    .getMap());
        }
        return flag;
    }
    //============================================================================================

    public int update(Course course) {
        return courseDao.update(MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(course))
                .addId(course.getId())
                .getMap()
        );
    }

    public List<Course> query(Course course) {
        //这些类的query()方法中，都粘贴这个
        if (course != null && course.getPage() != null) {
            PageHelper.startPage(course.getPage(), course.getLimit());
        }
        return courseDao.query(BeanMapUtils.beanToMap(course));
    }

    public Course detail(Integer id) {
        //{}内容与上面的delete()方法一样
        return courseDao.detail(MapParameter.getInstance()
                .addId(id)
                .getMap()); //add("id",id)
    }

    public int count(Course course) {
        return courseDao.count(BeanMapUtils.beanToMapForUpdate(course));
    }

}
