package com.wt.controller;

import com.wt.entity.Clazz;
import com.wt.entity.Subject;
import com.wt.service.ClazzService;
import com.wt.service.SubjectService;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/clazz")
public class ClazzController {

    private static final String LIST = "clazz/list"; //表页面
    private static final String ADD = "clazz/add";   //添加页面
    private static final String UPDATE = "clazz/update";//更新页面

    @Autowired
    private ClazzService clazzService;
    //======================================= 添加 ===============================================
    @Autowired
    private SubjectService subjectService;
    //============================================================================================


    @GetMapping("/add")
    public String add(ModelMap modelMap) {
        //======================================= 添加 ===============================================
        List<Subject> subjects = subjectService.query(null);
        modelMap.addAttribute("subjects",subjects); //增加属性
        //============================================================================================
        return ADD;
    }

    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Clazz clazz) {
        int result = clazzService.create(clazz);
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String, Object> delete(@PathVariable("id") Integer id) {
        int result = clazzService.delete(id);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String ids) {
        int result = clazzService.delete(ids);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Clazz clazz) {
        int result = clazzService.update(clazz);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    //======================================= 修改 ===============================================
    //详情（解决删除操作）
    @GetMapping("/detail/{id}")
    //@ResponseBody
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        Clazz clazz = clazzService.detail(id);
        List<Subject> subjects = subjectService.query(null);
        //if(clazz == null){
        //return MapControll.getInstance().nodata().getMap();
        //}
        //return MapControll.getInstance().success().put("data",clazz).getMap();
        modelMap.addAttribute("clazz", clazz);
        modelMap.addAttribute("subjects", subjects); //增加属性
        return UPDATE;
    }

    //============================================================================================
    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody Clazz clazz) {
        List<Clazz> list = clazzService.query(clazz);
        List<Subject> subjects = subjectService.query(null);
        //======================================= 添加 ===============================================
        //循环赋值
        //设置subject
        list.forEach(entity -> {
            subjects.forEach(subject -> {
                if (entity.getSubjectId() == subject.getId()) {
                    entity.setSubject(subject);
                }
            });
        });
        //============================================================================================
        Integer count = clazzService.count(clazz);
        return MapControll.getInstance().success()
                .put("data", list)
                .put("count", count)
                .getMap(); //put("data",clazz)是整个对象
    }

    @GetMapping("/list")
    public String list() {
        return LIST;
    }
}
