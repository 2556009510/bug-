package com.wt.controller;

import com.wt.entity.Course;
import com.wt.service.CourseService;
import com.wt.utils.MapControll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/course")
public class CourseController {

    private static final String LIST = "course/list"; //表页面
    private static final String ADD = "course/add";   //添加页面
    private static final String UPDATE = "course/update";//更新页面

    @Autowired
    private CourseService courseService;

    @GetMapping("/add")
    public String add() {
        return ADD;
    }

    //创建
    @PostMapping("/create")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Course course) {
        int result = courseService.create(course);
        if (result <= 0) {
            //新增失败
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        //map.put("200","操作成功"); 不用写（上面的类中解释）
        //操作成功+日期（日期直接在success()后面加上 put("date",new Date()). 即可）
        return MapControll.getInstance().success().getMap(); //操作成功
    }

    @PostMapping("/delete/{id}")
    @ResponseBody
    public Map<String, Object> delete(@PathVariable("id") Integer id) {
        int result = courseService.delete(id);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //复制上面的方法，并修改部分代码
    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String ids) {
        int result = courseService.delete(ids);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap();
        }
        return MapControll.getInstance().success().getMap();
    }

    //更改
    @PostMapping("/update")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Course course) {
        int result = courseService.update(course);
        if (result <= 0) {
            return MapControll.getInstance().error().getMap(); //操作失败
        }
        return MapControll.getInstance().success().getMap(); //操作成功
    }
    //============================================================================================
    //详情（解决删除操作）
    @GetMapping("/detail/{id}")
    //@ResponseBody
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        Course course = courseService.detail(id);
        //     if(course == null){
        //     return MapControll.getInstance().nodata().getMap();
        //}
        //return MapControll.getInstance().success().put("data",course).getMap();
        modelMap.addAttribute("course", course);
        return UPDATE;
    }
    //============================================================================================
    //查
    @PostMapping("/query")
    @ResponseBody
    public Map<String, Object> query(@RequestBody Course course) {
        List<Course> list = courseService.query(course);
        Integer count = courseService.count(course);
        return MapControll.getInstance().success()
                .put("data", list)
                .put("count", count)
                .getMap(); //put("data",course)是整个对象
    }

    @GetMapping("/list")
    public String list() {
        return LIST;
    }
}

