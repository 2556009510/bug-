package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.ScoreDao;
import com.wt.dao.ScoreDao;
import com.wt.entity.Score;
import com.wt.entity.Score;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MapParameter;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ScoreService {

    @Autowired
    private ScoreDao scoreDao;

    public int create(Score pi) {
        return scoreDao.create(pi);
    }

    //================================= 学生选课 =============================================
    public int create(String sectionIds, String courseIds, Integer studentId) {
        scoreDao.delete(MapParameter.getInstance()
                .add("stuId", studentId)
                .getMap());

        String[] sectionIdArr = sectionIds.split(",");
        String[] courseIdArr = courseIds.split(",");
        int flag = 0;
        for (int i = 0; i < sectionIdArr.length; i++) {
            Score score = new Score();
            score.setSectionId(Integer.parseInt(sectionIdArr[i]));
            score.setCourseId(Integer.parseInt(courseIdArr[i]));
            score.setStuId(studentId);
            flag = scoreDao.create(score);
        }
        return flag;
    }
    //=======================================================================================

    public int delete(Integer id) {
        return scoreDao.delete(MapParameter.getInstance().addId(id).getMap());
    }

    public int update(Score score) {
        Map<String, Object> map = MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(score))
                .addId(score.getId())
                .getMap();
        return scoreDao.update(map);
    }

    public int update(Integer courseId, Integer sectionId, String stuIds, String scores) {
        String[] stuIdArray = stuIds.split(",");
        String[] scoresArray = scores.split(",");
        int flag = 0;
        for (int i = 0; i < stuIdArray.length; i++) {
            Map<String, Object> map = MapParameter.getInstance()
                    .add("courseId", courseId)
                    .add("sectionId", sectionId)
                    .add("stuId", Integer.parseInt(stuIdArray[i]))
                    .add("updateScore", Integer.parseInt(scoresArray[i])).getMap();
            flag = scoreDao.update(map);
        }
        return flag;
    }

    public List<Score> query(Score score) {
        //这些类的query()方法中，都粘贴这个
        // if (score != null && score.getPage() != null) {
        //    PageHelper.startPage(score.getPage(), score.getLimit());
        // }
        return scoreDao.query(BeanMapUtils.beanToMap(score));
    }

    public Score detail(Integer id) {
        //{}内容与上面的delete()方法一样
        return scoreDao.detail(MapParameter.getInstance().addId(id).getMap());
    }

    public int count(Score score) {
        return scoreDao.count(BeanMapUtils.beanToMap(score));
    }

    public List<HashMap> queryScoreByStudent(Integer studentId) {
        Map<String, Object> map = MapParameter.getInstance()
                .add("studentId", studentId)
                .getMap();
        return scoreDao.queryScoreByStudent(map);
    }


    public List<HashMap> queryAvgScoreBySection() {
        //======================================= 写法1 =============================================
//        List<HashMap> mapList = scoreDao.queryAvgScoreBySection(null);
//        return mapList;
        //======================================= 写法2 =============================================
        return scoreDao.queryAvgScoreBySection(null);
        //==========================================================================================

    }


}

