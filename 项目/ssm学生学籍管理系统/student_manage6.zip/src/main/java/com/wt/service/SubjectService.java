package com.wt.service;

import com.github.pagehelper.PageHelper;
import com.wt.dao.SubjectDao;
import com.wt.dao.SubjectDao;
import com.wt.entity.Subject;
import com.wt.entity.Subject;
import com.wt.entity.Subject;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MapParameter;
import com.wt.utils.BeanMapUtils;
import com.wt.utils.MapParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SubjectService {

    @Autowired
    private SubjectDao subjectDao;

    public int create(Subject pi) {
        return subjectDao.create(pi);
    }

    public int delete(Integer id) {
        return subjectDao.delete(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }
//============================================================================
    //复制上面的方法，并修改部分代码
    public int delete(String ids) {
        int flag = 0;
        for (String s : ids.split(",")) {
            flag = subjectDao.delete(MapParameter.getInstance()
                    .addId(Integer.parseInt(s))
                    .getMap());
        }
        return flag;
    }
//============================================================================
    public int update(Subject subject) {
        Map<String, Object> map = MapParameter.getInstance()
                .add(BeanMapUtils.beanToMapForUpdate(subject))
                .addId(subject.getId())
                .getMap();
        return subjectDao.update(map);
    }

    public List<Subject> query(Subject subject) {
        //当查询条件有分页信息时，按照分页查询
        if(subject != null && subject.getPage() != null){
            PageHelper.startPage(subject.getPage(),subject.getLimit());
        }
        return subjectDao.query(BeanMapUtils.beanToMap(subject));
    }

    public Subject detail(Integer id) {
        //{}内容与上面的delete()方法一样
        return subjectDao.detail(MapParameter.getInstance()
                .addId(id)
                .getMap());
    }

    public int count(Subject subject) {
        return subjectDao.count(BeanMapUtils.beanToMap(subject));
    }


}
