package com.wt.service;//package com.wt.service;
//
//import com.github.pagehelper.PageHelper;
//import com.wt.dao.RequestDao;
//import com.wt.entity.Reques;
//import com.wt.entity.Request;
////import com.wt.utils.BeanMapUtils;
////import com.wt.utils.MapParameter;
//import com.wt.utils.BeanMapUtils;
//import com.wt.utils.MapParameter;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class RequestService {
//
//    @Autowired
//    private RequestDao requestDao;
//
//    public int create(Reques pi) {
//        return requesDao.create(pi);
//    }
//
//    public int delete(Integer id) {
//        return requesDao.delete(MapParameter.getInstance().addId(id).getMap());
//    }
//
//    public int update(Reques reques) {
//        return requesDao.update(BeanMapUtils.beanToMapForUpdate(reques));
//    }
//
//    public List<Reques> query(Reques reques) {
//        return requesDao.query(BeanMapUtils.beanToMapForUpdate(reques));
//    }
//
//    public Reques detail(Integer id) {
//        //{}内容与上面的delete()方法一样
//        return requesDao.detail(MapParameter.getInstance().addId(id).getMap());
//    }
//
//    public int count(Reques reques) {
//        return requesDao.count(BeanMapUtils.beanToMapForUpdate(reques));
//    }
//}
